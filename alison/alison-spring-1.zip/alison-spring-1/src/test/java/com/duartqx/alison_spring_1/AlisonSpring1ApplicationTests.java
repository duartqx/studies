package com.duartqx.alison_spring_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlisonSpring1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
